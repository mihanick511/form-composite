"use strict"
window.onload = function()
{
	mainObj.inition()
}
let mainObj =
{
	inition()
	{
		
	}
}